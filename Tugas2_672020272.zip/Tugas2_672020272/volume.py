def getVolumeKubus(sisi):return sisi*sisi
def getVolumeBalok(panjang, lebar):return panjang*lebar
def getVolumeLimasSegiEmpat(sisi, tinggi):return sisi*sisi*tinggi/3
def getVolumePrismaSegiTiga(panjang,lebar,tinggi):return (panjang*lebar/2)*tinggi